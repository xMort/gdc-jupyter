"use strict";
(self["webpackChunkjupyterlab_env_from_url"] = self["webpackChunkjupyterlab_env_from_url"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);

const searchedParameterPrefix = "env-";
const parseEnvParametersFromQuery = () => {
    const queryString = window.location.search.substring(1);
    return queryString
        .split("&")
        .filter((parameter) => parameter.startsWith(searchedParameterPrefix))
        .map((parameter) => {
        const [key, value] = parameter.substring(searchedParameterPrefix.length).split("=");
        const decodedValue = decodeURIComponent(value);
        return { key, value: decodedValue };
    });
};
const parseWindowQuery = () => {
    const envVariables = parseEnvParametersFromQuery();
    const pythonEnvVariablesLines = envVariables.map(({ key, value }) => `os.environ["${key}"] = "${value}"`);
    const pythonCodeLines = ["import os", ...pythonEnvVariablesLines];
    return pythonEnvVariablesLines.length > 0 ? pythonCodeLines.join("\n") : undefined;
};
/**
 * Initialization data for the jupyterlab_env_from_url extension.
 */
const plugin = {
    id: "jupyterlab_env_from_url:plugin",
    description: "A JupyterLab extension to parse window URL and setting param values to notebook env.",
    autoStart: true,
    optional: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, notebookTracker) => {
        console.log("JupyterLab extension jupyterlab_env_from_url is activated!");
        let initialized = false;
        notebookTracker === null || notebookTracker === void 0 ? void 0 : notebookTracker.currentChanged.connect(() => {
            if (notebookTracker.currentWidget) {
                notebookTracker.activeCellChanged.connect(() => {
                    var _a, _b, _c;
                    if (!initialized) {
                        const notebook = (_a = notebookTracker.currentWidget) === null || _a === void 0 ? void 0 : _a.content;
                        if (notebook && notebook.model) {
                            initialized = true;
                            const source = parseWindowQuery();
                            if (source) {
                                (_b = notebook.model) === null || _b === void 0 ? void 0 : _b.sharedModel.insertCell(1, {
                                    cell_type: notebook.notebookConfig.defaultCell,
                                    metadata: { trusted: true },
                                    source,
                                });
                                (_c = notebook.model) === null || _c === void 0 ? void 0 : _c.sharedModel.deleteCell(2);
                                console.log("The cell with insight information from window location has been injected.");
                            }
                            else {
                                console.log("No URL query parameters starting with `env-` found, skipping cell injection process.");
                            }
                        }
                    }
                });
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.ac31b3b3e2dbf603e843.js.map